return {
	"_preload.lua",
	"xbox360.lua",
	"xbox360_vcxproj.lua",
	"xbox360_sln2005.lua",
	"xbox360_vstudio.lua",
}
