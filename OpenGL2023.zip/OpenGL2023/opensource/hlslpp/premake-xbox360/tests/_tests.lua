require ("xbox360")

return {
	"test_xbox360_project.lua",
	"test_xbox360_project_vs200x.lua"
}
