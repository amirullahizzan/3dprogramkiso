// -------------------------------
// XYZW
// -------------------------------

hlslpp_swizzle_start uswizzle1<0> x; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<0, 0> xx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 0, 0> xxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 0, 0> xxxx; hlslpp_swizzle_end

// -------------------------------
// RGBA
// -------------------------------

hlslpp_swizzle_start uswizzle1<0> r; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<0, 0> rr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 0, 0> rrr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 0, 0> rrrr; hlslpp_swizzle_end