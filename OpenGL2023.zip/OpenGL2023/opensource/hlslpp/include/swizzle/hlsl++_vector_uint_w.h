// -------------------------------
// XYZW
// -------------------------------

hlslpp_swizzle_start uswizzle1<3> w; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle2<0, 3> xw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<1, 3> yw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<2, 3> zw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 0> wx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 1> wy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 2> wz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 3> ww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<0, 0, 3> xxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 1, 3> xyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 2, 3> xzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<0, 3, 0> xwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 3, 1> xwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 3, 2> xwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 3, 3> xww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<1, 0, 3> yxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 1, 3> yyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 2, 3> yzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<1, 3, 0> ywx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 3, 1> ywy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 3, 2> ywz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 3, 3> yww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<2, 0, 3> zxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 1, 3> zyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 2, 3> zzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<2, 3, 0> zwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 3, 1> zwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 3, 2> zwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 3, 3> zww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 0, 0> wxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 0, 1> wxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 0, 2> wxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 0, 3> wxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 1, 0> wyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 1, 1> wyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 1, 2> wyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 1, 3> wyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 2, 0> wzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 2, 1> wzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 2, 2> wzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 2, 3> wzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 3, 0> wwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 3, 1> wwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 3, 2> wwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 3, 3> www; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 0, 0, 3> xxxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 1, 3> xxyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 2, 3> xxzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 0, 3, 0> xxwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 3, 1> xxwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 3, 2> xxwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 3, 3> xxww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 1, 0, 3> xyxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 1, 3> xyyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 2, 3> xyzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 1, 3, 0> xywx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 3, 1> xywy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 3, 2> xywz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 3, 3> xyww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 2, 0, 3> xzxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 1, 3> xzyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 2, 3> xzzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 2, 3, 0> xzwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 3, 1> xzwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 3, 2> xzwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 3, 3> xzww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 0, 0> xwxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 0, 1> xwxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 0, 2> xwxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 0, 3> xwxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 1, 0> xwyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 1, 1> xwyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 1, 2> xwyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 1, 3> xwyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 2, 0> xwzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 2, 1> xwzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 2, 2> xwzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 2, 3> xwzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 3, 0> xwwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 3, 1> xwwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 3, 2> xwwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 3, 3> xwww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 0, 0, 3> yxxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 1, 3> yxyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 2, 3> yxzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 0, 3, 0> yxwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 3, 1> yxwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 3, 2> yxwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 3, 3> yxww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 1, 0, 3> yyxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 1, 3> yyyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 2, 3> yyzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 1, 3, 0> yywx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 3, 1> yywy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 3, 2> yywz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 3, 3> yyww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 2, 0, 3> yzxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 1, 3> yzyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 2, 3> yzzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 2, 3, 0> yzwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 3, 1> yzwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 3, 2> yzwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 3, 3> yzww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 0, 0> ywxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 0, 1> ywxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 0, 2> ywxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 0, 3> ywxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 1, 0> ywyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 1, 1> ywyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 1, 2> ywyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 1, 3> ywyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 2, 0> ywzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 2, 1> ywzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 2, 2> ywzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 2, 3> ywzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 3, 0> ywwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 3, 1> ywwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 3, 2> ywwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 3, 3> ywww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 0, 0, 3> zxxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 1, 3> zxyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 2, 3> zxzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 0, 3, 0> zxwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 3, 1> zxwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 3, 2> zxwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 3, 3> zxww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 1, 0, 3> zyxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 1, 3> zyyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 2, 3> zyzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 1, 3, 0> zywx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 3, 1> zywy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 3, 2> zywz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 3, 3> zyww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 2, 0, 3> zzxw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 1, 3> zzyw; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 2, 3> zzzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 2, 3, 0> zzwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 3, 1> zzwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 3, 2> zzwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 3, 3> zzww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 0, 0> zwxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 0, 1> zwxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 0, 2> zwxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 0, 3> zwxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 1, 0> zwyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 1, 1> zwyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 1, 2> zwyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 1, 3> zwyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 2, 0> zwzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 2, 1> zwzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 2, 2> zwzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 2, 3> zwzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 3, 0> zwwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 3, 1> zwwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 3, 2> zwwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 3, 3> zwww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 0, 0> wxxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 0, 1> wxxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 0, 2> wxxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 0, 3> wxxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 1, 0> wxyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 1, 1> wxyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 1, 2> wxyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 1, 3> wxyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 2, 0> wxzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 2, 1> wxzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 2, 2> wxzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 2, 3> wxzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 3, 0> wxwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 3, 1> wxwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 3, 2> wxwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 3, 3> wxww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 0, 0> wyxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 0, 1> wyxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 0, 2> wyxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 0, 3> wyxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 1, 0> wyyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 1, 1> wyyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 1, 2> wyyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 1, 3> wyyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 2, 0> wyzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 2, 1> wyzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 2, 2> wyzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 2, 3> wyzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 3, 0> wywx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 3, 1> wywy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 3, 2> wywz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 3, 3> wyww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 0, 0> wzxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 0, 1> wzxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 0, 2> wzxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 0, 3> wzxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 1, 0> wzyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 1, 1> wzyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 1, 2> wzyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 1, 3> wzyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 2, 0> wzzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 2, 1> wzzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 2, 2> wzzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 2, 3> wzzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 3, 0> wzwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 3, 1> wzwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 3, 2> wzwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 3, 3> wzww; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 0, 0> wwxx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 0, 1> wwxy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 0, 2> wwxz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 0, 3> wwxw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 1, 0> wwyx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 1, 1> wwyy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 1, 2> wwyz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 1, 3> wwyw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 2, 0> wwzx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 2, 1> wwzy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 2, 2> wwzz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 2, 3> wwzw; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 3, 0> wwwx; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 3, 1> wwwy; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 3, 2> wwwz; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 3, 3> wwww; hlslpp_swizzle_end

// -------------------------------
// RGBA
// -------------------------------

hlslpp_swizzle_start uswizzle1<3> a; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle2<0, 3> ra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<1, 3> ga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<2, 3> ba; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 0> ar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 1> ag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 2> ab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle2<3, 3> aa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<0, 0, 3> rra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 1, 3> rga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 2, 3> rba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<0, 3, 0> rar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 3, 1> rag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 3, 2> rab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<0, 3, 3> raa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<1, 0, 3> gra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 1, 3> gga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 2, 3> gba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<1, 3, 0> gar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 3, 1> gag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 3, 2> gab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<1, 3, 3> gaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<2, 0, 3> bra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 1, 3> bga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 2, 3> bba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<2, 3, 0> bar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 3, 1> bag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 3, 2> bab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<2, 3, 3> baa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 0, 0> arr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 0, 1> arg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 0, 2> arb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 0, 3> ara; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 1, 0> agr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 1, 1> agg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 1, 2> agb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 1, 3> aga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 2, 0> abr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 2, 1> abg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 2, 2> abb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 2, 3> aba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle3<3, 3, 0> aar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 3, 1> aag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 3, 2> aab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle3<3, 3, 3> aaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 0, 0, 3> rrra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 1, 3> rrga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 2, 3> rrba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 0, 3, 0> rrar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 3, 1> rrag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 3, 2> rrab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 0, 3, 3> rraa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 1, 0, 3> rgra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 1, 3> rgga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 2, 3> rgba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 1, 3, 0> rgar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 3, 1> rgag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 3, 2> rgab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 1, 3, 3> rgaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 2, 0, 3> rbra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 1, 3> rbga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 2, 3> rbba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 2, 3, 0> rbar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 3, 1> rbag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 3, 2> rbab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 2, 3, 3> rbaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 0, 0> rarr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 0, 1> rarg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 0, 2> rarb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 0, 3> rara; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 1, 0> ragr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 1, 1> ragg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 1, 2> ragb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 1, 3> raga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 2, 0> rabr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 2, 1> rabg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 2, 2> rabb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 2, 3> raba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<0, 3, 3, 0> raar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 3, 1> raag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 3, 2> raab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<0, 3, 3, 3> raaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 0, 0, 3> grra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 1, 3> grga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 2, 3> grba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 0, 3, 0> grar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 3, 1> grag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 3, 2> grab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 0, 3, 3> graa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 1, 0, 3> ggra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 1, 3> ggga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 2, 3> ggba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 1, 3, 0> ggar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 3, 1> ggag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 3, 2> ggab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 1, 3, 3> ggaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 2, 0, 3> gbra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 1, 3> gbga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 2, 3> gbba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 2, 3, 0> gbar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 3, 1> gbag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 3, 2> gbab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 2, 3, 3> gbaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 0, 0> garr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 0, 1> garg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 0, 2> garb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 0, 3> gara; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 1, 0> gagr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 1, 1> gagg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 1, 2> gagb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 1, 3> gaga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 2, 0> gabr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 2, 1> gabg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 2, 2> gabb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 2, 3> gaba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<1, 3, 3, 0> gaar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 3, 1> gaag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 3, 2> gaab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<1, 3, 3, 3> gaaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 0, 0, 3> brra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 1, 3> brga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 2, 3> brba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 0, 3, 0> brar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 3, 1> brag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 3, 2> brab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 0, 3, 3> braa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 1, 0, 3> bgra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 1, 3> bgga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 2, 3> bgba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 1, 3, 0> bgar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 3, 1> bgag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 3, 2> bgab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 1, 3, 3> bgaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 2, 0, 3> bbra; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 1, 3> bbga; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 2, 3> bbba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 2, 3, 0> bbar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 3, 1> bbag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 3, 2> bbab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 2, 3, 3> bbaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 0, 0> barr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 0, 1> barg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 0, 2> barb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 0, 3> bara; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 1, 0> bagr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 1, 1> bagg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 1, 2> bagb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 1, 3> baga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 2, 0> babr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 2, 1> babg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 2, 2> babb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 2, 3> baba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<2, 3, 3, 0> baar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 3, 1> baag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 3, 2> baab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<2, 3, 3, 3> baaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 0, 0> arrr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 0, 1> arrg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 0, 2> arrb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 0, 3> arra; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 1, 0> argr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 1, 1> argg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 1, 2> argb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 1, 3> arga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 2, 0> arbr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 2, 1> arbg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 2, 2> arbb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 2, 3> arba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 0, 3, 0> arar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 3, 1> arag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 3, 2> arab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 0, 3, 3> araa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 0, 0> agrr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 0, 1> agrg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 0, 2> agrb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 0, 3> agra; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 1, 0> aggr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 1, 1> aggg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 1, 2> aggb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 1, 3> agga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 2, 0> agbr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 2, 1> agbg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 2, 2> agbb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 2, 3> agba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 1, 3, 0> agar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 3, 1> agag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 3, 2> agab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 1, 3, 3> agaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 0, 0> abrr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 0, 1> abrg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 0, 2> abrb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 0, 3> abra; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 1, 0> abgr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 1, 1> abgg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 1, 2> abgb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 1, 3> abga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 2, 0> abbr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 2, 1> abbg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 2, 2> abbb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 2, 3> abba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 2, 3, 0> abar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 3, 1> abag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 3, 2> abab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 2, 3, 3> abaa; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 0, 0> aarr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 0, 1> aarg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 0, 2> aarb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 0, 3> aara; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 1, 0> aagr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 1, 1> aagg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 1, 2> aagb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 1, 3> aaga; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 2, 0> aabr; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 2, 1> aabg; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 2, 2> aabb; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 2, 3> aaba; hlslpp_swizzle_end

hlslpp_swizzle_start uswizzle4<3, 3, 3, 0> aaar; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 3, 1> aaag; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 3, 2> aaab; hlslpp_swizzle_end
hlslpp_swizzle_start uswizzle4<3, 3, 3, 3> aaaa; hlslpp_swizzle_end