// -------------------------------
// XYZW
// -------------------------------

hlslpp_swizzle_start dswizzle1<0> x; hlslpp_swizzle_end
hlslpp_swizzle_start dswizzle2<0, 0> xx; hlslpp_swizzle_end
hlslpp_swizzle_start dswizzle3<0, 0, 0> xxx; hlslpp_swizzle_end
hlslpp_swizzle_start dswizzle4<0, 0, 0, 0> xxxx; hlslpp_swizzle_end

// -------------------------------
// RGBA
// -------------------------------

hlslpp_swizzle_start dswizzle1<0> r; hlslpp_swizzle_end
hlslpp_swizzle_start dswizzle2<0, 0> rr; hlslpp_swizzle_end
hlslpp_swizzle_start dswizzle3<0, 0, 0> rrr; hlslpp_swizzle_end
hlslpp_swizzle_start dswizzle4<0, 0, 0, 0> rrrr; hlslpp_swizzle_end