// -------------------------------
// XYZW
// -------------------------------

hlslpp_swizzle_start iswizzle1<2> z; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle2<0, 2> xz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<1, 2> yz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<2, 0> zx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<2, 1> zy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<2, 2> zz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<0, 0, 2> xxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 1, 2> xyz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 2, 0> xzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 2, 1> xzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 2, 2> xzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<1, 0, 2> yxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 1, 2> yyz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 2, 0> yzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 2, 1> yzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 2, 2> yzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<2, 0, 0> zxx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 0, 1> zxy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 0, 2> zxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 1, 0> zyx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 1, 1> zyy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 1, 2> zyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<2, 2, 0> zzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 2, 1> zzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 2, 2> zzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 0, 0, 2> xxxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 0, 1, 2> xxyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 0, 2, 0> xxzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 0, 2, 1> xxzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 0, 2, 2> xxzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 1, 0, 2> xyxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 1, 1, 2> xyyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 1, 2, 0> xyzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 1, 2, 1> xyzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 1, 2, 2> xyzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 2, 0, 0> xzxx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 0, 1> xzxy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 0, 2> xzxz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 2, 1, 0> xzyx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 1, 1> xzyy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 1, 2> xzyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 2, 2, 0> xzzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 2, 1> xzzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 2, 2> xzzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 0, 0, 2> yxxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 1, 2> yxyz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 2, 0> yxzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 2, 1> yxzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 2, 2> yxzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 1, 0, 2> yyxz; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 1, 1, 2> yyyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 1, 2, 0> yyzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 1, 2, 1> yyzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 1, 2, 2> yyzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 2, 0, 0> yzxx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 0, 1> yzxy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 0, 2> yzxz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 2, 1, 0> yzyx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 1, 1> yzyy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 1, 2> yzyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 2, 2, 0> yzzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 2, 1> yzzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 2, 2> yzzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 0, 0, 0> zxxx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 0, 1> zxxy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 0, 2> zxxz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 0, 1, 0> zxyx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 1, 1> zxyy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 1, 2> zxyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 0, 2, 0> zxzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 2, 1> zxzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 2, 2> zxzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 1, 0, 0> zyxx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 0, 1> zyxy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 0, 2> zyxz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 1, 1, 0> zyyx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 1, 1> zyyy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 1, 2> zyyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 1, 2, 0> zyzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 2, 1> zyzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 2, 2> zyzz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 2, 0, 0> zzxx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 0, 1> zzxy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 0, 2> zzxz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 2, 1, 0> zzyx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 1, 1> zzyy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 1, 2> zzyz; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 2, 2, 0> zzzx; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 2, 1> zzzy; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 2, 2> zzzz; hlslpp_swizzle_end

// -------------------------------
// RGBA
// -------------------------------

hlslpp_swizzle_start iswizzle1<2> b; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle2<0, 2> rb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<1, 2> gb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<2, 0> br; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<2, 1> bg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle2<2, 2> bb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<0, 0, 2> rrb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 1, 2> rgb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 2, 0> rbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 2, 1> rbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<0, 2, 2> rbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<1, 0, 2> grb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 1, 2> ggb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 2, 0> gbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 2, 1> gbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<1, 2, 2> gbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<2, 0, 0> brr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 0, 1> brg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 0, 2> brb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 1, 0> bgr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 1, 1> bgg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 1, 2> bgb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle3<2, 2, 0> bbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 2, 1> bbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle3<2, 2, 2> bbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 0, 0, 2> rrrb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 0, 1, 2> rrgb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 0, 2, 0> rrbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 0, 2, 1> rrbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 0, 2, 2> rrbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 1, 0, 2> rgrb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 1, 1, 2> rggb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 1, 2, 0> rgbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 1, 2, 1> rgbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 1, 2, 2> rgbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 2, 0, 0> rbrr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 0, 1> rbrg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 0, 2> rbrb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 2, 1, 0> rbgr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 1, 1> rbgg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 1, 2> rbgb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<0, 2, 2, 0> rbbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 2, 1> rbbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<0, 2, 2, 2> rbbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 0, 0, 2> grrb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 1, 2> grgb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 2, 0> grbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 2, 1> grbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 0, 2, 2> grbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 1, 0, 2> ggrb; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 1, 1, 2> gggb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 1, 2, 0> ggbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 1, 2, 1> ggbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 1, 2, 2> ggbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 2, 0, 0> gbrr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 0, 1> gbrg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 0, 2> gbrb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 2, 1, 0> gbgr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 1, 1> gbgg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 1, 2> gbgb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<1, 2, 2, 0> gbbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 2, 1> gbbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<1, 2, 2, 2> gbbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 0, 0, 0> brrr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 0, 1> brrg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 0, 2> brrb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 0, 1, 0> brgr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 1, 1> brgg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 1, 2> brgb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 0, 2, 0> brbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 2, 1> brbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 0, 2, 2> brbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 1, 0, 0> bgrr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 0, 1> bgrg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 0, 2> bgrb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 1, 1, 0> bggr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 1, 1> bggg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 1, 2> bggb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 1, 2, 0> bgbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 2, 1> bgbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 1, 2, 2> bgbb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 2, 0, 0> bbrr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 0, 1> bbrg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 0, 2> bbrb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 2, 1, 0> bbgr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 1, 1> bbgg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 1, 2> bbgb; hlslpp_swizzle_end

hlslpp_swizzle_start iswizzle4<2, 2, 2, 0> bbbr; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 2, 1> bbbg; hlslpp_swizzle_end
hlslpp_swizzle_start iswizzle4<2, 2, 2, 2> bbbb; hlslpp_swizzle_end